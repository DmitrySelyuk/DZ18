using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Multiplication : MonoBehaviour
{
    public Transform Object1;
    public float Namber;

    void Update()
    {
        transform.position = Object1.position * Namber;
    }
}
